#!/bin/bash

ii=0
while [ $ii -lt 15 ]; do
  ./getroot `expr 1000000 + $ii`
  ii=`expr $ii + 1`
done

