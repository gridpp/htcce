#!/bin/bash

export X509_USER_PROXY=/home/dteam001/test/x509up_u460

ii=0
while [ $ii -lt 20 ]; do
  condor_ce_submit ce_test.sub
  ii=`expr $ii + 1 `
done

