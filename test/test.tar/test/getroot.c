#include <stdio.h>
#include <math.h>
#include <stdlib.h>



long long mysqrt(long long n)
{
     long long low = 0;
     long long high = n+1;
     while (high - low > 1)
     {
           long long mid = (low+high)/2;
           if (mid*mid <= n)
                 low = mid;
           else
                 high = mid;
     }
     
     return low;
}
void main(int argc, char* argv[]) {

  if (argc != 2) {
    printf("Give a value\n");
    exit(1);
  }
  long num = 0;
  long root = 0;
  int ii;
  for (ii=0; ii< 10000000;ii++) {
    num  = atoi(argv[1]);
    root = mysqrt(num+ii);
  }
  printf("Square root of %d is %d\n",num+ii,root);
}

